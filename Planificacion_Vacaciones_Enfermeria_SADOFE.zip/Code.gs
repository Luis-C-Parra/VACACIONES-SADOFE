/**
 * BACKEND OPCIONAL PARA "PLANIFICACIÓN DE VACACIONES · ENFERMERÍA"
 *
 * Este script se vincula al Google Spreadsheet que contiene:
 *   - pestaña "enfermeros": nombres del personal, preferentemente en columna A
 *   - pestaña "vacaciones": se crea automáticamente
 *   - pestaña "feriados": se crea automáticamente
 *
 * Luego:
 * 1) Implementar > Nueva implementación > Aplicación web
 * 2) Ejecutar como: usted
 * 3) Quién tiene acceso: cualquiera con el enlace (según las políticas de su cuenta)
 * 4) Copiar la URL /exec y pegarla en la app web.
 */

const SHEET_NURSES = 'enfermeros';
const SHEET_VAC = 'vacaciones';
const SHEET_HOL = 'feriados';
const DEFAULT_CYCLE = 2025;

function doGet(e) {
  const action = (e && e.parameter && e.parameter.action) || 'state';
  if (action === 'staff') {
    return json_({staff: getStaff_()});
  }
  return json_(getState_());
}

function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (body.action === 'saveState') {
      saveState_(body.state || {});
      return json_({ok:true, message:'Estado guardado'});
    }
    return json_({ok:false, message:'Acción no reconocida'});
  } catch (err) {
    return json_({ok:false, message:String(err)});
  }
}

function getStaff_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sh = ss.getSheetByName(SHEET_NURSES);
  if (!sh) return [];
  const values = sh.getRange(1,1,Math.max(sh.getLastRow(),1),1).getDisplayValues()
    .flat().map(x => String(x).trim()).filter(Boolean);
  // Ignora un encabezado habitual.
  return values.filter(x => !/^(enfermeros?|nombre|apellido y nombre)$/i.test(x));
}

function getState_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const staff = getStaff_();
  const vac = readSheet_(SHEET_VAC);
  const hol = readSheet_(SHEET_HOL);
  return {
    staff: staff,
    assignments: vac.slice(1).filter(r => r[0] && r[1]).map(r => ({
      nurse: String(r[0]), date: formatDate_(r[1]), note: r[2] || ''
    })),
    holidays: hol.slice(1).filter(r => r[0]).map(r => ({
      date: formatDate_(r[0]), name: r[1] || ''
    })),
    cycleStartYear: Number(PropertiesService.getScriptProperties().getProperty('cycleStartYear') || DEFAULT_CYCLE),
    sector: PropertiesService.getScriptProperties().getProperty('sector') || 'PISO ADULTO',
    shift: PropertiesService.getScriptProperties().getProperty('shift') || 'SADOFE'
  };
}

function saveState_(state) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  let vac = ss.getSheetByName(SHEET_VAC);
  if (!vac) vac = ss.insertSheet(SHEET_VAC);
  vac.clearContents();
  vac.getRange(1,1,1,3).setValues([['Enfermero','Fecha','Observación']]);
  const va = (state.assignments || []).map(a => [a.nurse, a.date, a.note || '']);
  if (va.length) vac.getRange(2,1,va.length,3).setValues(va);

  let hol = ss.getSheetByName(SHEET_HOL);
  if (!hol) hol = ss.insertSheet(SHEET_HOL);
  hol.clearContents();
  hol.getRange(1,1,1,2).setValues([['Fecha','Feriado']]);
  const ha = (state.holidays || []).map(h => [h.date, h.name || '']);
  if (ha.length) hol.getRange(2,1,ha.length,2).setValues(ha);

  const p = PropertiesService.getScriptProperties();
  p.setProperty('cycleStartYear', String(state.cycleStartYear || DEFAULT_CYCLE));
  p.setProperty('sector', String(state.sector || 'PISO ADULTO'));
  p.setProperty('shift', String(state.shift || 'SADOFE'));
}

function readSheet_(name) {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name);
  if (!sh || sh.getLastRow() < 1) return [];
  return sh.getDataRange().getValues();
}

function formatDate_(v) {
  if (v instanceof Date) {
    return Utilities.formatDate(v, Session.getScriptTimeZone(), 'yyyy-MM-dd');
  }
  const s = String(v).trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  const m = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
  return m ? `${m[3]}-${String(m[2]).padStart(2,'0')}-${String(m[1]).padStart(2,'0')}` : s;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
